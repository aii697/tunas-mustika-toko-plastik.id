// Data Storage
let currentUser = null;
let products = [
    { id: 1, name: 'Kantong Plastik HD', price: 5000, stock: 100 },
    { id: 2, name: 'Gelas Plastik', price: 3000, stock: 50 },
    { id: 3, name: 'Sedotan Plastik', price: 2000, stock: 200 },
    { id: 4, name: 'Wadah Makanan', price: 15000, stock: 30 }
];

let customers = [
    { id: 1, name: 'Umum', phone: '', address: '' },
    { id: 2, name: 'Ibu Sari', phone: '081234567890', address: 'Jl. Merdeka No. 1' },
    { id: 3, name: 'Bapak Joko', phone: '081234567891', address: 'Jl. Sudirman No. 2' }
];

let transactions = [];
let cart = [];

// Login System
function showLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
}

function login(username, password) {
    const users = {
        'admin': { password: 'admin123', role: 'Admin' },
        'kasir': { password: 'kasir123', role: 'Kasir' }
    };

    if (users[username] && users[username].password === password) {
        currentUser = {
            username: username,
            role: users[username].role
        };
        return true;
    }
    return false;
}

function logout() {
    currentUser = null;
    document.getElementById('dashboard').style.display = 'none';
    document.body.style.overflow = 'auto';
    showMainContent();
}

function showMainContent() {
    document.querySelector('.header').style.display = 'block';
    document.querySelector('.hero').style.display = 'block';
    document.querySelector('.features').style.display = 'block';
    document.querySelector('.products').style.display = 'block';
    document.querySelector('.contact').style.display = 'block';
    document.querySelector('.testimonials').style.display = 'block';
    document.querySelector('.footer').style.display = 'block';
}

function hideMainContent() {
    document.querySelector('.header').style.display = 'none';
    document.querySelector('.hero').style.display = 'none';
    document.querySelector('.features').style.display = 'none';
    document.querySelector('.products').style.display = 'none';
    document.querySelector('.contact').style.display = 'none';
    document.querySelector('.testimonials').style.display = 'none';
    document.querySelector('.footer').style.display = 'none';
}

function showDashboard() {
    hideMainContent();
    document.getElementById('dashboard').style.display = 'block';
    document.getElementById('userRole').textContent = '(' + currentUser.role + ')';
    document.body.style.overflow = 'hidden';
    
    // Load initial data
    loadCustomerOptions();
    loadProductList();
    loadCustomerList();
}

// Tab Management
function showTab(tabName) {
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => btn.classList.remove('active'));
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
}

// Transaction Management
function loadCustomerOptions() {
    const customerSelect = document.getElementById('customer');
    customerSelect.innerHTML = '<option value="">Pilih Pelanggan</option>';
    
    customers.forEach(customer => {
        const option = document.createElement('option');
        option.value = customer.id;
        option.textContent = customer.name;
        customerSelect.appendChild(option);
    });
}

function addToCart(productId, quantity = 1) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.productId === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            productId: productId,
            name: product.name,
            price: product.price,
            quantity: quantity
        });
    }
    
    updateCartDisplay();
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.productId !== productId);
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p>Keranjang kosong</p>';
        cartTotal.textContent = '0';
        return;
    }
    
    let html = '';
    let total = 0;
    
    cart.forEach(item => {
        const subtotal = item.price * item.quantity;
        total += subtotal;
        
        html += `
            <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid #e5e7eb;">
                <div>
                    <strong>${item.name}</strong><br>
                    <small>Rp ${item.price.toLocaleString()} x ${item.quantity}</small>
                </div>
                <div>
                    <span>Rp ${subtotal.toLocaleString()}</span>
                    <button onclick="removeFromCart(${item.productId})" style="margin-left: 10px; background: #ef4444; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    });
    
    cartItems.innerHTML = html;
    cartTotal.textContent = total.toLocaleString();
}

function processTransaction() {
    if (cart.length === 0) {
        alert('Keranjang kosong!');
        return;
    }
    
    const customerId = document.getElementById('customer').value;
    const paymentMethod = document.getElementById('paymentMethod').value;
    
    if (!customerId || !paymentMethod) {
        alert('Mohon lengkapi data transaksi!');
        return;
    }
    
    const transaction = {
        id: transactions.length + 1,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().split(' ')[0],
        customerId: parseInt(customerId),
        paymentMethod: paymentMethod,
        items: [...cart],
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        cashier: currentUser.username
    };
    
    transactions.push(transaction);
    
    // Update stock
    cart.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (product) {
            product.stock -= item.quantity;
        }
    });
    
    // Clear cart
    cart = [];
    updateCartDisplay();
    
    // Print receipt
    printReceipt(transaction);
    
    alert('Transaksi berhasil diproses!');
    loadProductList(); // Refresh product list to show updated stock
}

function printReceipt(transaction) {
    const customer = customers.find(c => c.id === transaction.customerId);
    
    let receiptContent = `
        =====================================
              TUNAS MUSTIKA
           Toko Plastik Terpercaya
        =====================================
        Alamat: Jl. Gajah Mada No III C
                G.Pangilun
        Telp: 301469684
        =====================================
        Tanggal: ${transaction.date}
        Waktu: ${transaction.time}
        Kasir: ${transaction.cashier}
        Pelanggan: ${customer ? customer.name : 'Umum'}
        =====================================
        DETAIL PEMBELIAN:
        =====================================
    `;
    
    transaction.items.forEach(item => {
        const subtotal = item.price * item.quantity;
        receiptContent += `
        ${item.name}
        ${item.quantity} x Rp ${item.price.toLocaleString()} = Rp ${subtotal.toLocaleString()}
        `;
    });
    
    receiptContent += `
        =====================================
        TOTAL: Rp ${transaction.total.toLocaleString()}
        Pembayaran: ${transaction.paymentMethod.toUpperCase()}
        =====================================
        Terima kasih atas kunjungan Anda!
        =====================================
    `;
    
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>Struk Pembayaran</title>
            <style>
                body { font-family: monospace; font-size: 12px; margin: 20px; }
                pre { white-space: pre-wrap; }
            </style>
        </head>
        <body>
            <pre>${receiptContent}</pre>
            <script>
                window.onload = function() {
                    window.print();
                    window.onafterprint = function() {
                        window.close();
                    }
                }
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// Product Management
function loadProductList() {
    const productList = document.getElementById('productList');
    
    let html = `
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; margin-top: 1rem;">
    `;
    
    products.forEach(product => {
        html += `
            <div style="border: 1px solid #e5e7eb; padding: 1rem; border-radius: 8px; background: white;">
                <h4>${product.name}</h4>
                <p>Harga: Rp ${product.price.toLocaleString()}</p>
                <p>Stok: ${product.stock}</p>
                <div style="margin-top: 1rem;">
                    <button onclick="addToCart(${product.id})" class="btn btn-primary" style="margin-right: 0.5rem;">
                        <i class="fas fa-cart-plus"></i> Tambah ke Keranjang
                    </button>
                    ${currentUser.role === 'Admin' ? `
                        <button onclick="editProduct(${product.id})" class="btn btn-outline" style="margin-right: 0.5rem;">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button onclick="deleteProduct(${product.id})" class="btn" style="background: #ef4444; color: white;">
                            <i class="fas fa-trash"></i> Hapus
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    productList.innerHTML = html;
}

function showAddProductForm() {
    if (currentUser.role !== 'Admin') {
        alert('Hanya admin yang dapat menambah produk!');
        return;
    }
    
    const name = prompt('Nama Produk:');
    const price = prompt('Harga:');
    const stock = prompt('Stok:');
    
    if (name && price && stock) {
        const newProduct = {
            id: products.length + 1,
            name: name,
            price: parseInt(price),
            stock: parseInt(stock)
        };
        
        products.push(newProduct);
        loadProductList();
        alert('Produk berhasil ditambahkan!');
    }
}

function editProduct(productId) {
    if (currentUser.role !== 'Admin') {
        alert('Hanya admin yang dapat mengedit produk!');
        return;
    }
    
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const name = prompt('Nama Produk:', product.name);
    const price = prompt('Harga:', product.price);
    const stock = prompt('Stok:', product.stock);
    
    if (name && price && stock) {
        product.name = name;
        product.price = parseInt(price);
        product.stock = parseInt(stock);
        
        loadProductList();
        alert('Produk berhasil diperbarui!');
    }
}

function deleteProduct(productId) {
    if (currentUser.role !== 'Admin') {
        alert('Hanya admin yang dapat menghapus produk!');
        return;
    }
    
    if (confirm('Apakah Anda yakin ingin menghapus produk ini?')) {
        products = products.filter(p => p.id !== productId);
        loadProductList();
        alert('Produk berhasil dihapus!');
    }
}

// Customer Management
function loadCustomerList() {
    const customerList = document.getElementById('customerList');
    
    let html = `
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; margin-top: 1rem;">
    `;
    
    customers.forEach(customer => {
        if (customer.name === 'Umum') return; // Skip default customer
        
        html += `
            <div style="border: 1px solid #e5e7eb; padding: 1rem; border-radius: 8px; background: white;">
                <h4>${customer.name}</h4>
                <p>Telepon: ${customer.phone}</p>
                <p>Alamat: ${customer.address}</p>
                <div style="margin-top: 1rem;">
                    ${currentUser.role === 'Admin' ? `
                        <button onclick="editCustomer(${customer.id})" class="btn btn-outline" style="margin-right: 0.5rem;">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button onclick="deleteCustomer(${customer.id})" class="btn" style="background: #ef4444; color: white;">
                            <i class="fas fa-trash"></i> Hapus
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    customerList.innerHTML = html;
}

function showAddCustomerForm() {
    const name = prompt('Nama Pelanggan:');
    const phone = prompt('Nomor Telepon:');
    const address = prompt('Alamat:');
    
    if (name && phone && address) {
        const newCustomer = {
            id: customers.length + 1,
            name: name,
            phone: phone,
            address: address
        };
        
        customers.push(newCustomer);
        loadCustomerList();
        loadCustomerOptions();
        alert('Pelanggan berhasil ditambahkan!');
    }
}

function editCustomer(customerId) {
    if (currentUser.role !== 'Admin') {
        alert('Hanya admin yang dapat mengedit pelanggan!');
        return;
    }
    
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    const name = prompt('Nama Pelanggan:', customer.name);
    const phone = prompt('Nomor Telepon:', customer.phone);
    const address = prompt('Alamat:', customer.address);
    
    if (name && phone && address) {
        customer.name = name;
        customer.phone = phone;
        customer.address = address;
        
        loadCustomerList();
        loadCustomerOptions();
        alert('Data pelanggan berhasil diperbarui!');
    }
}

function deleteCustomer(customerId) {
    if (currentUser.role !== 'Admin') {
        alert('Hanya admin yang dapat menghapus pelanggan!');
        return;
    }
    
    if (confirm('Apakah Anda yakin ingin menghapus pelanggan ini?')) {
        customers = customers.filter(c => c.id !== customerId);
        loadCustomerList();
        loadCustomerOptions();
        alert('Pelanggan berhasil dihapus!');
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Login form submission
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (login(username, password)) {
            closeLoginModal();
            showDashboard();
        } else {
            alert('Username atau password salah!');
        }
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        const modal = document.getElementById('loginModal');
        if (e.target === modal) {
            closeLoginModal();
        }
    });
    
    // Initialize cart display
    updateCartDisplay();
});